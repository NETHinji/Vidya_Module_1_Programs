﻿
using System;

namespace GatePassApplication.Entities
{
    public class GatePass
    {
        public int GatePassID { get; set; }
        public string VisitorName { get; set; }
        public DateTime DateOfVisit { get; set; }
        public long ContactNo { get; set; }
        public string PurposeOfVisit { get; set; }
        public string ContactPerson { get; set; }
    }
}