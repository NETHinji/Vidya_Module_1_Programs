﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorExample
{
    class Calculator
    {

        public static void CalculateInterest(int pri, float rate, float noOfYears)
        {
            float si = (pri * rate * noOfYears) / 100;
            //return si;
            Console.WriteLine("Simple Interest " + si);
        }

        static void Main(string[] args)
        {
            try
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                Type t = assembly.GetType("CalculatorExample.Calculator");
                MethodInfo methodInfo = t.GetMethod("CalculateInterest", BindingFlags.Public | BindingFlags.Static);
                float result = Convert.ToInt32(methodInfo.Invoke(null, new object[]{ 22000, 3.1F, 2.1F }));
                Console.WriteLine(result);
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
       
    }
}
