﻿using GatePassApplication.BusinessLogicLayer;
using GatePassApplication.Entities;
using GatePassApplication.GatePassExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GatePassApplication.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int choice;
                do
                {
                    PrintMenu();
                    Console.WriteLine("Enter Your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch(choice)
                    {
                        case 1:
                            AddVisitor();
                            break;

                        case 2:
                            SearchVisitor();
                            break;

                        case 3:
                            DisplayVisitorList();
                            break;
                        default:
                            Console.WriteLine("Invalid Choice...");
                            break;

                    }                  
                } while (choice!=-1);

            }
            catch (SystemException sys)
            {

                throw new GatePassException(sys.Message);
            }

        }

        private static void DisplayVisitorList()
        {
            try
            {
                
                GatePassBL gpbl = new GatePassBL();
                List<GatePass> passList = gpbl.GetAllGatePasses();
                GatePass gpb = new GatePass();
                if (passList != null)
                {
                    Console.WriteLine("=========================================================================");
                    Console.WriteLine("GatePassID\tVisitorName\tDateOfVisit\tContactNumber\tPurposeOfVisit\tContactPerson");
                    Console.WriteLine("=========================================================================");
                    foreach (GatePass gate in passList)
                    {
                        Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}", gate.GatePassID, gate.VisitorName, gate.DateOfVisit, gate.ContactNo, gate.PurposeOfVisit, gate.ContactPerson);
                    }
                    Console.WriteLine("==========================================================================");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private static void SearchVisitor()
        {
            try
            {
                int gpID;
                Console.WriteLine("Enter Gate Pass ID of Which you have to search details:");
                gpID = Convert.ToInt32(Console.ReadLine());
                GatePassBL gatePassBL = new GatePassBL();
                GatePass gp = gatePassBL.SearchVisitorByID(gpID);
                if(gp!=null)
                {
                    Console.WriteLine("==========================================================================================");
                    Console.WriteLine("GatePassID\t\tVisitorName\t\tDateOfVisit\t\tContactNumber\t\tPurposeOfVisit\t\tContactPerson");
                    Console.WriteLine("==========================================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", gp.GatePassID, gp.VisitorName, gp.DateOfVisit,gp.ContactNo,gp.PurposeOfVisit,gp.ContactPerson);
                    Console.WriteLine("==========================================================================================");
                }
                else
                {
                    Console.WriteLine("Visitor's Details Not Available");
                }
            }
            catch (SystemException sys)
            {

                throw new GatePassException(sys.Message);
            }
        }

        private static void AddVisitor()
        {
            try
            {
                GatePassBL gatePassBL = new GatePassBL();
                GatePass gatePass = new GatePass();
                Random r = new Random();
                gatePass.GatePassID = r.Next(10000, 99999);
                Console.WriteLine("Enter Visitor Name:");
                gatePass.VisitorName = Console.ReadLine();
                Console.WriteLine("Enter Date of Visit:");
                gatePass.DateOfVisit = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Contact Number:");
                gatePass.ContactNo = Console.ReadLine();
                Console.WriteLine("Enter Purpose of Visit:");
                gatePass.PurposeOfVisit = Console.ReadLine();
                Console.WriteLine("Enter Contact Person:");
                gatePass.ContactPerson = Console.ReadLine();
                bool visitorAdded = gatePassBL.AddVisit(gatePass);
                if(visitorAdded)
                {
                    Console.WriteLine("Visitor Added"+gatePass.GatePassID);
                }
                else
                {
                    Console.WriteLine("Visitor not Added");
                }

            }
            catch (SystemException sys)
            {

                throw new GatePassException(sys.Message);
            }
        }
        

        public static void PrintMenu()
        {
            Console.WriteLine("1. Add Visitor");
            Console.WriteLine("2. Search Visitor");
            Console.WriteLine("3. Display Visitor's List");
        }
    }
}
