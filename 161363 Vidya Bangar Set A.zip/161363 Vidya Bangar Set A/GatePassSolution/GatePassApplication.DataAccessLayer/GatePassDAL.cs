﻿using System;
using System.Collections.Generic;
using GatePassApplication.Entities;
using GatePassApplication.GatePassExceptions;

namespace GatePassApplication.DataAccessLayer
{
    public class GatePassDAL
    {
        static List<GatePass> VisitorList = new List<GatePass>();
        public GatePassDAL()
        {
        }


        //=========: Adding User :=============
        public bool AddVisitor(GatePass gatePass)
        {
            bool visitorAdded = false;
            try
            {
                VisitorList.Add(gatePass);
                visitorAdded = true;
            }
            catch (SystemException sys)
            {

                throw new GatePassException(sys.Message);
            }
            return visitorAdded;
        }

        public List<GatePass> GetAllGatePass()
        {
            return VisitorList;
        }

        public GatePass SearchGatePassDAL(int searchVisitorID)
        {
            try
            {

                GatePass searchVisitor = VisitorList.Find(GatePass => GatePass.GatePassID == searchVisitorID);
                return searchVisitor;
            }
            catch (SystemException ex)
            {
                throw new GatePassException(ex.Message);
            }

        }
        enum VisitPurpose
        {
            Meeting,
            Interview,
            Training
        }
    }
}